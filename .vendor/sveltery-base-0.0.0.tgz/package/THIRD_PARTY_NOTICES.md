# Third-party notices

Accordion Root, Item, Header, Trigger, Panel, value and DOM-order registration behavior, and assertion/type ports derive from packages/react/src/accordion and the pinned Collapsible/Button/lifecycle helpers at Base UI v1.8.0 commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. MIT attribution and immutable source/assertion hashes are preserved in parity/accordion.

Avatar Root, Image, Fallback, private detached/rendered image loading, fallback timing and presence/animation completion and assertion/type ports derive from packages/react/src/avatar, useTransitionStatus, useOpenChangeComplete, useAnimationsFinished and useTimeout at Base UI v1.8.0 commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. MIT attribution and complete immutable source/assertion hashes are preserved in parity/avatar.

Meter parts, numeric range normalization, formatter/locale cache, label/ID registration, hidden CSS and assertion/conformance ports derive from packages/react/src/meter and its rendering/ref, label registration and packages/utils dependency closure at Base UI v1.8.0 commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. MIT attribution and immutable source/assertion hashes are preserved in parity/meter.

Collapsible Root, Trigger, Panel, bounded measurement/motion lifecycle and assertion/type ports derive from packages/react/src/collapsible, useControlled, useTransitionStatus and useAnimationsFinished at Base UI v1.8.0 commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. MIT attribution and immutable source/assertion hashes are preserved in parity/collapsible.

Progress parts, range normalization, formatting, ID registration, visually hidden CSS and assertion/conformance ports derive from packages/react/src/progress, utils/useRegisteredLabelId.ts, packages/utils number/locale/clamp helpers and test conformance helpers at Base UI v1.8.0 commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. MIT attribution and immutable source/assertion hashes are preserved in parity/progress.

Toggle standalone state, callbacks, disabled behavior and assertion ports derive from toggle/Toggle.tsx, toggle/Toggle.test.tsx, utils/useControlled.ts and internals/use-button/useButton.ts at Base UI v1.8.0 commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. Their MIT notice and immutable source/assertion hashes also appear in parity/toggle.

Standalone Input native/control behavior, default state, IDs, value callbacks and conformance adapters derive from input/Input.tsx, input/Input.test.tsx, field/control/FieldControl.tsx, internals/field-root-context/FieldRootContext.ts and label/state helpers at Base UI v1.8.0 commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. Their source hashes and MIT license are retained in parity/input. Field/Form contextual integration remains unimplemented.

Separator orientation, role, state attributes and assertion/conformance ports derive from separator/Separator.tsx, separator/Separator.test.tsx, separator/SeparatorDataAttributes.ts and test conformance helpers at Base UI v1.8.0 commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. Their MIT notice and exact source hashes also appear in parity/separator.

Button native/custom keyboard, disabled and focusability semantics and assertion ports derive from button/Button.tsx, internals/use-button/useButton.ts, utils/useFocusableWhenDisabled.ts and utils/dispatchClickWithModifiers.ts at the pin below. Toast manager/store/promise algorithms and public data option types, event detail utilities, reason constants, selected test bodies/type assertions, and type-equality helpers are derived from mui/base-ui v1.8.0, commit 47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c. Composed focus traversal, native tabbable candidate/filter rules, details visibility, and default tab-index normalization derive from upstream floating-ui-react/utils/tabbable.ts and utils/shadowDom.ts at the same pin. Modal focus guards and their Apple WebKit accessibility attributes reference floating-ui-react/components/FloatingFocusManager.tsx, utils/FocusGuard.tsx, and utils/platform at that pin. Native merge behavior references upstream merge-props code and is covered by this notice. Dialog accessibility isolation references upstream FloatingFocusManager and markOthers traversal/attribute ownership behavior; its Svelte-native implementation is also covered by this notice. Source: https://github.com/mui/base-ui/tree/47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c/packages/react/src/internals

MIT License

Copyright (c) 2019 Material-UI SAS

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
